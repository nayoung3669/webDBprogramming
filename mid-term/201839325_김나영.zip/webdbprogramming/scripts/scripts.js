document.getElementById("title").innerHTML = "Javascript is Fun, Actually!";
