# Web Programming

Welcome to Web Programming course. In this page, you will find all the material related to the lecture.

웹개발 과목을 등록하는 학생 여러분께 짐심으로 환영합니다. 
해당 페이지에서는 강의 관련 내용이 나와있습니다.

## We will discuss about particularly about the backend programming that will cover Javascript, NodeJS, ExpressJS and MySQL database in particular. 