const fs = require("fs");
const path = require("path");
const express = require("express");
const mysql = require("mysql");

const app = express();

app.use("/scripts", express.static(__dirname + "/scripts"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "ums",
});

//const host = "localhost";

app.listen(3000, () => {
  console.log("누군가 연락했다");
});

// 처리해주는 함수
app.get("/", (req, res) => {
  res.sendStatus(404);
  //res.sendFile(__dirname+"/pages/index.html");
});

/** mid-term 중간고사  */

// register 경로 추가, register.html 파일 렌더링
app.get("/register", (req, res) => {
  res.sendFile(__dirname + "/pages/register.html");
});

//user 추가 register post 요청
app.post("/process/register", (req, res) => {
  const params = req.body;
  const username = params.username;
  const pwd = params.pwd;
  const email = params.email;
  const login_count = 0;
  const imported = 0;

  //유저 정보
  console.log("user : ", username, pwd, email, login_count, imported);

  //form Data 만들기
  const dataObj = { username, pwd, email, login_count, imported };
  const filePath = path.join(__dirname, "users.json");

  let users;
  try {
    const fileData = fs.readFileSync(filePath);
    users = JSON.parse(fileData);
  } catch (error) {
    users = [];
  }

  users.push(dataObj);

  //데이터 덮어쓰기
  fs.writeFileSync(filePath, JSON.stringify(users));
  res.send("<h1>Successfully signed up!</h1>");
});

// 로그인 로직
app.get("/login", (req, res) => {
  res.sendFile(__dirname + "/pages/login.html");
});

app.post("/process/login", (req, res) => {
  const params = req.body;
  const username = params.username;
  const pwd = params.pwd;

  const importUser = async (email) => {
    pool.getConnection((err, conn) => {
      if (err) throw err;
      const exec = conn.query(
        "INSERT INTO users (username, pwd, email) VALUES (?, password(?), ?)",
        [username, pwd, email],
        (err, _) => {
          conn.release();
          console.log("SQL", exec.sql);
          if (!err) {
            res.send(`아이디가 추가되었습니다.`);
            return true;
          } else {
            console.log("오류가 발생했습니다.");
            return false;
          }
        },
      );
    });
  };

  fs.readFile("users.json", "utf-8", async (e, data) => {
    if (e) {
      console.log("something went wrong");
    } else {
      const dataObj = JSON.parse(data);
      const user = dataObj.find(
        (user) => user.username === username && user.pwd === pwd,
      );
      if (user) {
        console.log("회원정보 일치");
        user.login_count += 1;
        if (user.login_count >= 5 && user.imported === 0) {
          (await importUser(user.email)) ? (user.imported += 1) : null;
        }
        fs.writeFileSync("users.json", JSON.stringify(dataObj));
        res.send(`<h2>로그인 성공. 아이디: ${user.username}</h2>`);
      } else {
        console.log("아이디 또는 비밀번호가 틀립니다");
      }
    }
  });
});
